# Práctica Integradora de Campo I · Cerro Redondo – Paramillos de Uspallata

Viernes 16 y sábado 17 de octubre de 2026 · pernocte en el campo

Javier Gómez Figueroa (responsable) · José Mescua · Laura León · David Candia

## Teledetección: cómo se hizo

Sentinel-2 L2A (ESA Copernicus): mediana de 9 escenas de verano sin nubes (2019–2026), 10–20 m. EMIT (NASA, Estación Espacial Internacional): dos escenas hiperespectrales sin nubes (20/01/2025 y 19/01/2026), 285 bandas, píxel 60 m, minerales identificados con Tetracorder (USGS). ASTER (NASA/METI): reflectancia SWIR de 2000 y 2007 y emisividad térmica AG100 (~100 m). Procesado para PIC I 2026.

- **EMIT**: reflectancia corregida por atmósfera y mineral identificado por Tetracorder (USGS) en dos fechas independientes. Sólo se aceptó un mineral con banda ≥ 0,02; donde las fechas coinciden (68 % de los píxeles en 2 µm, 82 % en 1 µm) el mapa es opaco.
- **Química de la mica blanca**: posición del mínimo Al-OH (≈2200 nm) con remoción del continuo y ajuste cuadrático, en las dos fechas. Diferencia media entre fechas: 1,1 nm (r = 0,76).
- **ASTER**: índices SWIR (Al-OH, caolinita, Mg-OH) de 2000 y 2007, y cuarzo, sílice, carbonato y máficos de la emisividad térmica AG100.
- **Síntesis**: zonas por mineral dominante; la “fílica probable” es mica con banda en el cuartil más profundo (≥ 0,087) y Al-OH en el cuartil más corto (≤ 2204 nm).

### ¿Funciona acá? Control con depósitos conocidos

| Depósito | S2 OH | S2 Fe³⁺ | EMIT (300 m) |
|---|---|---|---|
| Cerro Canario | p99 | p98 | mica 59 % · caol+mica 24 % |
| Paramillos Sur | p98 | p97 | caol+mica 53 % · mica 30 % |
| Paramillos Centro | p83 | p93 | mica 38 % · carbonatos |
| Oro del Sur | p78 | p75 | mica 70 % |
| Paramillos Norte | p64 | p89 | carbonatos · esmectita |
| Vetas Paramillos | p38 | p36 | carbonatos 91 % · Fe²⁺ |

S2: percentil del valor alto (p90 local, 250 m) respecto de toda el área. EMIT: proporción de píxeles en 300 m. Los pórfiros y el epitermal con alteración expuesta dan mica blanca ± caolinita; las vetas dan su ganga carbonática y los basaltos de caja.

### Qué ve EMIT en cada parada

| Parada | 2 µm (arcillas, micas) | 1 µm (Fe) |
|---|---|---|
| 2026.1 | caol+mica 46 % · esmectita 19 % | hematita 95 % |
| 2026.2 | caolinita 21 % · dickita/nacrita 20 % | hematita 49 % · goethita 45 % |
| 2026.3 | caol+mica 33 % | hematita 94 % |
| 2026.4 | calcita+mica 31 % · mica 18 % | goethita 72 % |
| 2026.5 | caolinita 63 % · dickita/nacrita 16 % | goethita 56 % · hematita 39 % |
| 2026.6 | carbonatos 64 % · mica 23 % | Fe²⁺ 100 % |
| 2026.7 | esmectita 37 % · calcita+mica 21 % | hematita 70 % |

2026.1 y 2026.3: capas rojas. 2026.2 y 2026.5: bordes de los dos sistemas argílicos (B1 y B2–B3); ASTER da cuarzo p95 en 2026.5. 2026.6: basaltos triásicos. Radio de 300 m.

## Fuentes

- Cátedra PIC I (2026): guía de campo, programa y presentación metodológica.
- Orellano Ricchetti, Winocur y Rubinstein (2017), RAGA 74(2): geología y estructura de las vetas de Paramillos de Uspallata.
- Orellano Ricchetti, tesis doctoral (UBA): estratigrafía y estructura del depocentro Paramillos.
- Carrasquero (2015), tesis doctoral: magmatismo mioceno (Fm. Cerro Redondo).
- Brea, Artabe y Spalletti (2009), RAGA 64(1): bosque de Darwin en Agua de la Zorra.
- SEGEMAR (1999): Carta Geológica de la República Argentina 1:100.000, Hoja 3369-09 Uspallata.
- Datos satelitales: ESA Copernicus (Sentinel-2 L2A); NASA LP DAAC: EMIT L2A RFL, L2A MASK y L2B MIN V001; ASTER AST_07XT y AST_05 V004; ASTER GED AG100 V003. Tetracorder: Clark et al. (2003), USGS.
- Relieve: Copernicus DEM GLO-30 (ESA) vía Mapterhorn.
